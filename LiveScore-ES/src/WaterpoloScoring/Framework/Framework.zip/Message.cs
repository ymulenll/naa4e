﻿namespace LiveScoreEs.Framework
{
    public class Message
    {
        public string SagaId { get; protected set; }
    }
}