﻿namespace LiveScoreEs.Framework
{
    public class Command : Message
    {
    }
}